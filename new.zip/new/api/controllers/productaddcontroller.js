const Productdb = require('../models/productdb')


exports.productadd = async(req,res)=>{
    const{name, description, price} = req.body
    const record = new Productdb({pname:name, pdesc:description, pprice:price})
    await record.save()
    res.json(record)
}

exports.productfetch = async(req,res)=>{
    const record = await Productdb.find()
    res.json(record)
}

exports.productid = async(req,res)=>{
    const id = req.params.id
    const record = await Productdb.findById(id)
    res.json(record)
}

exports.productupdate = async(req,res)=>{
    const id = req.params.id
    const{name, description, price, status} = req.body
    await Productdb.findByIdAndUpdate(id,{pname:name, pdesc:description, pprice:price, pstatus:status})
    res.json({message : "Successfully Updated"})
}

exports.productdelete = async(req,res)=>{
    const id = req.params.id
    await Productdb.findByIdAndDelete(id)
    res.json({message:'Successfully Delete'})
}

exports.productcfetchhome = async(req,res)=>{
    const product = await Productdb.find({pstatus:'IN STOCK'})
    res.json(product)
}

exports.singleproductfetch = async(req,res)=>{
    const id = req.params.id
    const record = await Productdb.findById(id)
    res.json(record)
}