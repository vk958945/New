const Testimonialdb = require('../models/testimonialdb')

exports.tesimonialform = async(req,res)=>{
    const{name,desc,company} = req.body
    const testi = new Testimonialdb({tname: name, tdesc:desc, tcompanyname:company})
    await testi.save()
    res.json({message:'Successfully Posted'})
}

exports.testimonialallfetch = async(req,res)=>{
    const testi = await Testimonialdb.find()
    res.json(testi)
}

exports.testisinghdelete = async(req,res)=>{
    const id = req.params.id
    await Testimonialdb.findByIdAndDelete(id)
    res.json({message:"Successfully Deleted"})
}

exports.testiroleupdate = async(req,res)=>{
    const id = req.params.id
    const record = await Testimonialdb.findById(id)

    let newStatus = null
    if(record.tstatus=='Private'){
        newStatus = 'Public'
    }else{
        newStatus = 'Private'
    }

    await Testimonialdb.findByIdAndUpdate(id,{tstatus:newStatus})
    res.json({message:"Successfully Updated"})
}

exports.testiallfetches = async(req,res)=>{
    const testi = await Testimonialdb.find({tstatus:'Public'})
    res.json(testi)
}