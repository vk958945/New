const Addressdb = require('../models/addressdb')

exports.addressadd = async(req,res)=>{
    const{address,mobile,telephone,cname,desc,image} = req.body
    const record = new Addressdb({caddress:address, cmobile:mobile, ctelephone:telephone, cname:cname, cdesc:desc, cimage:image})
    await record.save()
    res.json(record)
}

exports.addressmngfetch = async(req,res)=>{
    const address = await Addressdb.findOne()
    res.json(address)
}

exports.addresssinglefetch = async(req,res)=>{
    const id = req.params.id
    const record = await Addressdb.findById(id)
    res.json(record)
}

exports.addresssingupdate = async(req,res)=>{
    const{address,mobile,telephone,cname,desc,image} = req.body
    const id = req.params.id
    await Addressdb.findByIdAndUpdate(id,{caddress:address, cmobile:mobile, ctelephone:telephone, cname:cname, cdesc:desc, cimage:image})
    res.json({message : "Successfully Updated"})
}

exports.addressfetchhome = async(req,res)=>{
    const record = await Addressdb.findOne()
    res.json(record)
}