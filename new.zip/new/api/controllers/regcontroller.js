const Regdb = require('../models/regdb')
const bcrypt = require('bcrypt')


exports.reginsert = async(req,res)=>{
    const{username,password} = req.body
    const passcrypt = await bcrypt.hash(password,10)
    const usercheck = await Regdb.findOne({username:username})
    if(usercheck==null){
    const record = new Regdb({username:username,password:passcrypt})
    await record.save()
    res.json(record)
    }else{
        res.json({message:"Username already taken"})
    }
}

exports.reglogin = async(req,res)=>{
    const{username,password} = req.body
    const record = await Regdb.findOne({username:username})
    if(record!==null){
        const passcompare = await bcrypt.compare(password,record.password)
        if(passcompare){
        res.json(record)
        }else{
            res.json({message:"Wrong Password"})
        }
    }else{
        res.json({message:"Wrong Username"})
    }
}

exports.usersfetch = async(req,res)=>{
    const record = await Regdb.find()
    res.json(record)
}

exports.userstatus = async(req,res)=>{
    const id = req.params.id
    const record = await Regdb.findById(id)
    
    let newstatus = null

    if(record.status=='Active'){
        newstatus='Suspended'
    }else{
        newstatus='Active'
    }

    await Regdb.findByIdAndUpdate(id,{status:newstatus})
    res.json({message:'Successfully Updated'})
}