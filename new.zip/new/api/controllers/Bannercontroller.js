const Bannerdb = require('../models/bannerdb')


exports.banneradd = async(req,res)=>{
    const{bname,bdescription,blongdescription,bimage} = req.body
    const banner = new Bannerdb({bname:bname,bdesc:bdescription,blongdesc:blongdescription,bimage:bimage})
    await banner.save()
    res.json(banner)
}

exports.bannermngfetch = async(req,res)=>{
    const banner = await Bannerdb.findOne()
    res.json(banner)

}

exports.bannersinglefetch = async(req,res)=>{
    const id = req.params.id
    const banner = await Bannerdb.findById(id)
    res.json(banner)
}

exports.bannermngupdate = async(req,res)=>{
    const{bname,bdescription,blongdescription,bimage} = req.body
    const id = req.params.id
    await Bannerdb.findByIdAndUpdate(id,{bname:bname,bdesc:bdescription,blongdesc:blongdescription,bimage:bimage})
    res.json({message:"Successfully Updated"})
}

exports.bannermngdelete = async(req,res)=>{
    //console.log(req.params.id)
    const id = req.params.id
    await Bannerdb.findByIdAndDelete(id)
    res.json({message:'Successfully Delete'})
    
}

exports.bannerhomeshow = async(req,res)=>{
    const banner = await Bannerdb.findOne()
    res.json(banner)
}

exports.bannermoredetail = async(req,res)=>{
    const banner = await Bannerdb.findOne()
    res.json(banner)
}