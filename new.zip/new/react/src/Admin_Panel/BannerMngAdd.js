import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Left from "./Left";

function BannerMngAdd() { 
    const[bname,setBname] = useState('')
    const[bdescription,setBdescription] = useState('')
    const[blongdescription,setBlongdescription] = useState('')
    const[bimage,setBimage] = useState('')
    const navigate = useNavigate()
    function handleform(e){
        e.preventDefault()
       const formdata = {bname,bdescription,blongdescription,bimage}
        fetch('/api/bannermngadd',{
            method:"POST",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                navigate('/banner')
            }
        })
    }

    return ( 
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9 mt-2 text-success">
                        <h2 className="text-center m-2">Banner Add Here</h2>
                    <form onSubmit={(e)=>{handleform(e)}}>

                        <label className="form-label fw-bold">Banner Title Name</label>
                        <input type='text' className="form-control"
                        value={bname} onChange={(e)=>{setBname(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Banner Description</label>
                        <input type='text' className="form-control"
                        value={bdescription} onChange={(e)=>{setBdescription(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Banner Long Description</label>
                        <textarea className="form-control"
                        value={blongdescription} onChange={(e)=>{setBlongdescription(e.target.value)}}></textarea>
                        
                        
                        <label className="form-label fw-bold">Banner Image</label>
                        <input type='file' className="form-control"
                        value={bimage} onChange={(e)=>{setBimage(e.target.value)}}
                        />

                        <button type='submit' className="form-control btn btn-success mt-2 mb-2 fw-bold">Banner Add</button>
                    </form>
                    </div>
                </div>
            </div>
        </section>
     );
}

export default BannerMngAdd;