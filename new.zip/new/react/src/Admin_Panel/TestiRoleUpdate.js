import { useNavigate, useParams } from "react-router-dom";

function TestiRoleUpdate() {
    const {id} = useParams()
    const navigate = useNavigate()

    fetch(`/api/testiroleupdate/${id}`,{
        method:"PUT",
        headers:{"Content-Type":"application/json"}
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==="Successfully Updated"){
            navigate('/testimonial')
        }
    })

    return ( 
        <h2>TestiRoleUpdate {id}</h2>
     );
}

export default TestiRoleUpdate;