import { useNavigate, useParams } from "react-router-dom";

function BannerMngDelete() {
    const{id} = useParams()
    const navigate = useNavigate()
    
    fetch(`/api/bannermngdelete/${id}`,{
        method:'DELETE'
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==='Successfully Delete'){
            navigate('/banner')
        }
    })
    return ( 
        <h2>Data Deleted {id}</h2>
     );
}

export default BannerMngDelete;