
import { useEffect, useState } from "react";
import Left from "./Left";
import { Link } from "react-router-dom";

function Testimonial(){
    const[testi,setTesti] = useState([])
    //const[dataloading,setDataloading] = useState(true)

    useEffect(()=>{
        fetch('/api/testimonialallfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setTesti(data)
        })
    },[])
    


    return (
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9 mt-2">
                        <h2>Testinominals Management</h2>

                        {/*dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>*/}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Company Name</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                {testi.map((result,key)=>(
                                <tr key={result._id}>
                                <td>{key+1}</td>
                                <td>{result.tname}</td>
                                <td>{result.tdesc}</td>
                                <td>{result.tcompanyname}</td>
                                    
                   
                                <td><Link to={`/testiroleupdate/${result._id}`}><button className="form-control btn btn-primary">{result.tstatus}</button></Link></td>
                      

                                

                                <td><Link to={`/testidelete/${result._id}`}><button className="form-control btn btn-danger">Delete</button></Link></td>
                            </tr>
                                ))}
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Testimonial;