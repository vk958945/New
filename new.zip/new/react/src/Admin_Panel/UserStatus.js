import { useNavigate, useParams } from "react-router-dom";

function UserStatus() {
    const {id} = useParams()
    const navigate = useNavigate()

    

    fetch(`/api/userstatus/${id}`,{
        method:"PUT",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify()
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==="Successfully Updated"){
            navigate('/users')
        }
    })

    return ( 
        <>
        <h2>UserStatus {id}</h2>

        </>
     );
}

export default UserStatus;