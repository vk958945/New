import { useEffect, useState } from "react";
import Left from "./Left";
import { Link } from "react-router-dom";

function UsersManagement() {
    const[user,setUser] = useState([])
    const[dataloading,setDataloading] = useState(true)

    useEffect(()=>{
        fetch('/api/usersfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloading(false)
            setUser(data)
        })
    },[])
    
    return ( 
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9 mt-2">
                        <h2>Users Management</h2>
                         {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                         <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>User Name</th>
                                    <th>User Status</th>
                                    <th>Id Role</th>
                                </tr>
                            </thead>

                            <tbody>
                                {user.map((result,key)=>(
                                <tr key={result._id}>
                                <td>{key+1}</td>
                                <td>{result.username}</td>
                                <td><Link to={`/userstatus/${result._id}`}><button>{result.status}</button></Link></td>
                                <td><Link to={`/useridrole/${result._id}`}><button>{result.useridrole}</button></Link></td>
                            </tr>
                                ))}                        
                            </tbody>
                        </table>
                        </div>
                </div>
            </div>
        </section>
     );
}

export default UsersManagement;