import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Left from "./Left";

function Products() {

    const[product,setProduct] = useState([])
    const[dataloading,setDataloading] = useState(true)

    useEffect(()=>{
        fetch('/api/productfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloading(false)
            setProduct(data)

        })
    },[])
    

    return (
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9 mt-2">
                        <h2>Product Management</h2>

                    <Link to='/productadd'> <button className=" form-control btn btn-primary">Product Add Here</button> </Link>
                        {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Product Name</th>
                                    <th>Product Description</th>
                                    <th>Product Price</th>
                                    <th>Status</th>
                                    <th>Action1</th>
                                    <th>Action2</th>
                                </tr>
                            </thead>
                            <tbody>
                            {product.map((result,key)=>(
                                <tr key={result._id}>
                                    <td>{key+1}</td>
                                    <td>{result.pname}</td>
                                    <td>{result.pdesc}</td>
                                    <td>{result.pprice}</td>
                                    <td>{result.pstatus}</td>
                                    <td><Link to={`/productupdate/${result._id}`}><button className="form-contol btn btn-primary">Update</button></Link></td>
                                    <td><Link to={`/productdelete/${result._id}`}><button className="form-contol btn btn-danger">Delete</button></Link></td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Products;