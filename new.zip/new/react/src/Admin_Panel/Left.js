import { Link } from "react-router-dom";

function Left() {
    return ( 
        <div className="col-md-3">
            <Link to='/banner'><button className="form-control btn btn-primary mt-2">Banner Management</button></Link>
            <Link to='/product'><button className="form-control btn btn-primary mt-1">Products Management</button></Link>
            <Link to='/testimonial'><button className="form-control btn btn-primary mt-1">Testimonial Management</button></Link>
            <Link to='/query'><button className="form-control btn btn-primary mt-1">Query Management</button></Link>
            <Link to='/address'><button className="form-control btn btn-primary mt-1">Address Management</button></Link>
            <Link to='/users'><button className="form-control btn btn-primary mt-1">Users Management</button></Link>
        </div>
     );
}

export default Left;