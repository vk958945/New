import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Left from "./Left";

function ProductUpdate() {

    const[name,setName] = useState('')
    const[description,setDescription] = useState('')
    const[price,setPrice] = useState('')
    const[status,setStatus] = useState('')
    const navigate = useNavigate()
    const{id} = useParams()
    useEffect(()=>{
        fetch(`/api/productid/${id}`).then((res)=>{ return res.json()}).then((data)=>{
            console.log(data)
            setName(data.pname)
            setDescription(data.pdesc)
            setPrice(data.pprice)
            setStatus(data.pstatus)
        })
    },[id])
    

    function handleform(e){
        e.preventDefault()
        const formdata = {name,description,price,status}
        
        fetch(`/api/productupdate/${id}`,{
            method:"PUT",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)         
            if(data.message==="Successfully Updated"){
                navigate('/product')
            }
        })
    }
        
    

    return ( 

        <section id="admin">
        <div className="container">
            <div className="row">
                <Left/>
                <div className="col-md-9 mt-2 text-success">
                    <h2 className="text-center m-2">Product update Here</h2>
                <form onSubmit={(e)=>{handleform(e)}}>

                    <label className="form-label fw-bold">Product Name</label>
                    <input type='text' className="form-control"
                    value={name} onChange={(e)=>{setName(e.target.value)}}
                    />

                    <label className="form-label fw-bold">Product Description</label>
                    <input type='text' className="form-control"
                    value={description} onChange={(e)=>{setDescription(e.target.value)}}
                    />

                    <label className="form-label fw-bold">Product Price</label>
                    <input type='number' className="form-control"
                    value={price} onChange={(e)=>{setPrice(e.target.value)}}
                    />

                    <label className="form-label fw-bold">Product Status</label>
                    <select name className="form-select" value={status} onChange={(e)=>{setStatus(e.target.value)}}>
                        <option value='IN STOCK'>IN STOCK</option>
                        <option value='OUT STOCK'> OUT STOCK</option>
                    </select>
                    
                    

                    <button type='submit' className="form-control btn btn-success mt-2 mb-2 fw-bold">Update</button>
                </form>
                </div>
            </div>
        </div>
    </section> 
     );
}

export default ProductUpdate;