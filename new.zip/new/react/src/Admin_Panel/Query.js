
import Left from "./Left";

function Query(){

    //const[dataloading,setDataloading] = useState(true)

    /*useEffect(()=>{
        fetch('/api/testinominalstfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
        })
    },[])
    */

    return (
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9 mt-2">
                        <h2>Queries Management</h2>

                        {/*dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>*/}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Email Id</th>
                                    <th>Query</th>
                                    <th>Status</th>

                                </tr>
                            </thead>
                            <tbody>
   
                                <tr>
                                    <td>{}</td>
                                    <td>{}</td>
                                    <td>{}</td>
                                    <td>{}</td>
                                    <td>{}</td>
                                </tr>
                        
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Query;