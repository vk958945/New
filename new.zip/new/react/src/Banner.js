import { useEffect, useState } from "react";
import { Link } from "react-router-dom";


function Banner() {

  const[banner,setBanner] =useState([])

  useEffect(() => {
    fetch('/api/bannerhomeshow').then((res) => { return res.json() }).then((data) => {
      //console.log(data)
      setBanner(data)
    })

  }, [])

  return (
    <section id="banner">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h4>{banner.bname}</h4>
            <p>{banner.bdesc}</p>
            <Link to="/bannermoredetail"><button className="btn btn-success">More details</button></Link>
          </div>
          <div className="col-md-6"><img src="media/about-us.png" alt="" className="img-fluid mx-auto d-block" id="img-banner" /></div>
        </div>
      </div>
      <img src="media/border1.png" alt="" />
    </section>
  );

}
export default Banner;