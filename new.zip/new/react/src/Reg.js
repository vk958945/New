import { useState } from "react";
import { Link } from "react-router-dom";

function Reg() {
    const[username,setUsername] = useState('')
    const[password,setPassword] = useState('')
    const[message,setMessage] = useState('')
    
    function handleform(e){
        e.preventDefault()
        const formdata = {username,password}
        fetch('/api/reg',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                setMessage("Successfully Registered")
            }else{
                setMessage("Username already taken")
            }
        })
    }   

    return ( 
        <section id="reg">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4" id="regmid">
                        <h2>Registration Here</h2>
                        {message}
                        <form onSubmit={(e)=>{handleform(e)}}>
                            <label className="form-label fw-bold">Username</label>
                            <input type="text" className="form-control"
                            value={username} onChange={(e)=>{setUsername(e.target.value)}}
                            ></input>
                            <label className="form-label fw-bold">Password</label>
                            <input type="text" className="form-control"
                            value={password} onChange={(e)=>{setPassword(e.target.value)}}
                            ></input>
                            <button type="submit" className="form-control btn btn-primary mt-2 mb-2 fw-bold">Register</button>
                        </form>
                        <Link to={'/login'}>Already have account? Please Login here.</Link>
                    </div>
                    <div className="col-md-4"></div>
                </div>
            </div>
        </section>
     );
}

export default Reg;