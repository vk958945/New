import { useEffect, useState } from "react";

function Footer() {
  const [address,setAddress] = useState([])
  useEffect(()=>{
    fetch('/api/addressfetchhome').then((res)=>{return res.json()}).then((data)=>{
      //console.log(data)
      setAddress(data)
    })
  },[])

    return ( 
        <section id="footer">
    <img src="/media/border2.png" alt="" id="footer-border"/>
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <img src="/media/logo.png" alt="" id="footerlog"/>
          <p>{address.cdesc}</p>
        </div>
        <div className="col-md-4">
          <h2>{address.cname}</h2>
          <p><span><i className="bi bi-house"></i></span> {address.caddress} </p>
          <p><span><i className="bi bi-phone"></i></span> +91-{address.cmobile}</p>
          <p><span><i className="bi bi-telephone"></i></span> {address.ctelephone}</p>
        </div>
        <div className="col-md-4">
          <form action="/query" method="post">
            <h2>Query form</h2>
            <input type="email" name="email" id="" placeholder="Enter Email" className="form-control"/>
            <textarea name="query" id="" placeholder="Enter Query" className="form-control mt-2 mb-2"></textarea>
            <button type="submit" className="form-control btn btn-success">Post Query</button>
          </form>
        </div>

      </div>
    </div>
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          <img src="/media/instagram-icon.png" alt=""/>
          <img src="/media/linkedin-icon.png" alt=""/>
          <img src="/media/twitter-icon.png" alt=""/>
          <img src="/media/snapchat-icon.png" alt=""/>
        </div>
      </div>
    </div>
  </section>
        );
}

export default Footer;