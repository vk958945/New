import { useState } from "react";
import { useNavigate } from "react-router-dom";

function TestimonialForm() {
    const[name,setName] = useState('')
    const[desc,setDesc] = useState('')
    const[company,setCompany] = useState('')

    const navigate = useNavigate()

    function handleform(e){
        e.preventDefault()
        const formdata = {name,desc,company}
        fetch('/api/tesimonialform',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data.message==='Successfully Posted'){
                navigate('/')
            }
        })
    }


    return (
        <section>
            <div className="container">
                <div className="row">
                    <div className="col-12-md mb-5">
                        <h2 style={{textAlign:'center', marginTop:'40px',marginBottom:'20px'}}> My Testimonial </h2>
                        <form onSubmit={(e) => { handleform(e) }}>

                            <label className="form-label fw-bold">Name</label>
                            <input type='text' className="form-control"
                                value={name} onChange={(e) => { setName(e.target.value) }}
                            />

                            <label className="form-label fw-bold">Testimonial Description</label>
                            <input type='text' className="form-control"
                                value={desc} onChange={(e) => { setDesc(e.target.value) }}
                            />

                            <label className="form-label fw-bold">Comapny Name</label>
                            <input type='text' className="form-control"
                                value={company} onChange={(e) => { setCompany(e.target.value) }}
                            />

                            <button type='submit' className="form-control btn btn-success mt-2 mb-2 fw-bold">Sumbit</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default TestimonialForm;