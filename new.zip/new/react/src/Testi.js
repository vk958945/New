import { useEffect, useState } from "react";

function Tetsi() {
const[testi,setTesti] = useState([])
  useEffect(()=>{
    fetch('/api/testiallfetches').then((res)=>{return res.json()}).then((data)=>{
      //console.log(data)
      setTesti(data)
    })
  },[])
  

    return (   
      <>
      <h2 id="services-h2">Testimonial</h2>
    <section id="testi">
      {testi.map((result,key)=>(
    <div className="container pt-3 pb-3" key={result._id}>
    <div className="row" >
      <div className="col-md-12">
        <img src="media/building.png" alt=""/>
        <h5><span><i className="bi bi-quote"></i></span> {result.tname} <i className="bi bi-quote"></i></h5>
        <p><span><i className="bi bi-quote"></i></span> {result.tdesc} <i className="bi bi-quote"></i></p>
        <p> {result.tcompanyname} </p>
      </div>

    </div>
  </div>
      ))}
  </section> 
  </>
  );
}

export default Tetsi;