import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LoginContext } from "./LoginContext";

function Login() {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [message, setMessage] = useState('')
    const navigate = useNavigate()

    const { setLoginname, setLoginStatus } = useContext(LoginContext)
    function handleform(e) {
        e.preventDefault()
        const formdata = { username, password }
        fetch('/api/login', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formdata)
        }).then((res) => { return res.json() }).then((data) => {
            console.log(data)
            if (data._id) {


                if (data.username === 'admin') {
                    if (data.status === 'Active') {
                        localStorage.setItem('loginname', data.username)
                        setLoginname(localStorage.getItem('loginname'))
                        localStorage.setItem('loginstatus', 1)
                        setLoginStatus(localStorage.getItem('loginstatus'))
                        navigate('/admin')
                    }
                    else {
                        setMessage('Your account is suspended. Please cordinate with your admin.')
                    }


                }
                else if (data.username !== 'admin') {
                    if (data.status === 'Active') {
                        localStorage.setItem('loginname', data.username)
                        setLoginname(localStorage.getItem('loginname'))
                        localStorage.setItem('loginstatus', 1)
                        setLoginStatus(localStorage.getItem('loginstatus'))
                        navigate('/')
                    }
                    else {
                        setMessage('Your account is suspended. Please cordinate with your admin.')
                    }
                }

            } else {
                setMessage("Wrong Credentials")
            }
        })
    }

    return (
        <section id="login">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4" id="loginmid">
                        <h2>Login Here</h2>
                        <div style={{ color: 'red' }}>{message}</div>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label className="form-label fw-bold">Username</label>
                            <input type="text" className="form-control"
                                value={username} onChange={(e) => { setUsername(e.target.value) }}
                            ></input>
                            <label className="form-label fw-bold">Password</label>
                            <input type="text" className="form-control"
                                value={password} onChange={(e) => { setPassword(e.target.value) }}
                            ></input>
                            <button type="submit" className="form-control btn btn-primary mt-2 mb-2 fw-bold">Login</button>
                        </form>
                        <Link to={'/reg'}>Don't have account? Please Register.</Link>
                    </div>
                    <div className="col-md-4"></div>
                </div>
            </div>
        </section>
    );
}

export default Login;