import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Header from "./Header";
import Footer from "./Footer";
import Home from './Home';
import About from './About';
import Login from './Login';
import Reg from './Reg';
import { useEffect, useState } from 'react';
import { LoginContext } from './LoginContext';
import Admin from './Admin_Panel/Admin';
import Products from './Admin_Panel/Products';
import ProductAdd from './Admin_Panel/ProductAdd';
import ProductUpdate from './Admin_Panel/ProductUpdate';
import ProductDelete from './Admin_Panel/ProductDelete';
import Testimonial from './Admin_Panel/Testimonial';
import Query from './Admin_Panel/Query';
import BannerManagement from './Admin_Panel/BannerManagement';
import BannerMngAdd from './Admin_Panel/BannerMngAdd';
import BannerMngUpdate from './Admin_Panel/BannerMngUpdate';
import BannerMngDelete from './Admin_Panel/BannerMngDelete';
import BannerMoreDetails from './BannerMoreDetails';
import TestimonialForm from './TestimonialForm';
import TestiDelete from './Admin_Panel/TestiDelete';
import TestiRoleUpdate from './Admin_Panel/TestiRoleUpdate';
import UsersManagement from './Admin_Panel/UsersManagement';
import UserStatus from './Admin_Panel/UserStatus';
import AddressManagement from './Admin_Panel/AddressManagement';
import AddressAdd from './Admin_Panel/AddressAdd';
import AddressUpdate from './Admin_Panel/AddressUpdate';
import ProductMoreDetail from './ProductMoreDetail';
import Cart from './Cart';


function App() {
  const [loginname, setLoginname] = useState(localStorage.getItem('loginname'))
  const [loginstatus, setLoginStatus] = useState(localStorage.getItem('loginstatus'))
  const[cart,setCart] = useState('')
  useEffect(()=>{
    localStorage.setItem('cart',JSON.stringify(cart))
  },[cart])

  return (
    
      <LoginContext.Provider value={{ loginname, setLoginname, loginstatus, setLoginStatus, cart, setCart }}>
        <Router>
          <Header />
          <Routes>
            {loginstatus ?
            <>
            <Route path='/about' element={<About />}></Route>            
            <Route path='/admin' element={<Admin />}></Route>
            <Route path='/banner' element={<BannerManagement />}></Route>
            <Route path='/bannermoredetail' element={<BannerMoreDetails />}></Route>
            <Route path='/bannermngadd' element={<BannerMngAdd />}></Route>
            <Route path='/bannermngupdate/:id' element={<BannerMngUpdate />}></Route>
            <Route path='/bannermngdelete/:id' element={<BannerMngDelete />}></Route>
            <Route path='/product' element={<Products />}></Route>
            <Route path='/productadd' element={<ProductAdd />}></Route>
            <Route path='/productupdate/:id' element={<ProductUpdate />}></Route>
            <Route path='/productdelete/:id' element={<ProductDelete />}></Route>
            <Route path='/testimonial' element={<Testimonial />}></Route>
            <Route path='/testiformshow' element={<TestimonialForm />}></Route>
            <Route path='/testidelete/:id' element={<TestiDelete />}></Route>
            <Route path='/testiroleupdate/:id' element={<TestiRoleUpdate />}></Route>
            <Route path='/query' element={<Query />}></Route>
            <Route path='/address' element={<AddressManagement />}></Route>
            <Route path='/addressadd' element={<AddressAdd />}></Route>
            <Route path='/addressupdate/:id' element={<AddressUpdate />}></Route>
            <Route path='/users' element={<UsersManagement />}></Route>
            <Route path='/userstatus/:id' element={<UserStatus />}></Route>
            <Route path='/productmoresetail/:id' element={<ProductMoreDetail />}></Route>
            <Route path='/cart' element={<Cart />}></Route>
            </>
            :
            <>
            <Route path='/' element={<Home />}></Route>
            <Route path='/login' element={<Login />}></Route>
            <Route path='/reg' element={<Reg />}></Route>           
            </>
            }
            
          </Routes>
          <Footer />
        </Router>
      </LoginContext.Provider>
    
  );
}

export default App